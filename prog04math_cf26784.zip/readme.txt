Conor Flood
Last Updated: 10/17/19

There are 4 main recursive functions that make up this project:
1. The isPrime function reads in a number that the user inputs and outputs "true" is the number is prime and "false"
otherwise. It also utilizes a helper function called "primeHelper".
2. The printPrimes function reads in a number n from user input and returns all the prime numbers between 1 and n.
This utilizes a helper function called "printHelper".
3. The findFibo function returns the nth Fibonacci number from a user-inputed number n.
4. The findFactors function reads in a number n from user input and prints all the prime factors of n. This utilizes a
helper function called "findFactorsHelper".

 Running the Program:
 1. Unzip the file prog04math_cf26784.zip
 2. Compile and run on Linux